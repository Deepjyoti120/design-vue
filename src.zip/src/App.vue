<template>
  <router-view />
</template> 